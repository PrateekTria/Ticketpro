package com.ticketpro.parking.activity;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.ticketpro.parking.R;

/**
 * Created by Rohit on 22-09-2020.
 */
class TicketPreviewActivity  extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_preview);
    }
}
