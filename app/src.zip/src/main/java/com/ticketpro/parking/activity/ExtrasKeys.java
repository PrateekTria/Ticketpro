package com.ticketpro.parking.activity;
public class ExtrasKeys {
    public static final String EXTRAS_RECOGNITION_SETTINGS = "EXTRAS_RECOGNITION_SETTINGS";
    public static final String EXTRAS_LICENSE_KEY = "EXTRAS_LICENSE_KEY";
    public static final String EXTRAS_RECOGNITION_RESULTS = "EXTRAS_RECOGNITION_RESULTS";
    public static final String EXTRAS_IMAGE_PATH = "EXTRAS_IMAGE_PATH";
}