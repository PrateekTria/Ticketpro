package com.ticketpro.parking.bl;

public class DateConfBLProcessor extends BLProcessorImpl{
	
	public DateConfBLProcessor(){
		setLogger(DateConfBLProcessor.class.getName());
	}

}
