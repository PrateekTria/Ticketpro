package com.ticketpro.model;

/**
 * This file is created by Triazine 20/1/20
 */
public class ParkeonLot {
    private String  control_group_id;
    private String name;
    private String desc;

    public String getControl_group_id() {
        return control_group_id;
    }

    public void setControl_group_id(String control_group_id) {
        this.control_group_id = control_group_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
