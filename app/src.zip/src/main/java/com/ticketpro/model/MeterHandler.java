package com.ticketpro.model;

public interface MeterHandler {
    public void meterResponse(Meter meter,String meterString);
}
