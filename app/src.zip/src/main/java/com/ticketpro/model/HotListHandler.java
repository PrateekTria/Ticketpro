package com.ticketpro.model;

public interface HotListHandler {
    public void hotListHandler(boolean result);
}
