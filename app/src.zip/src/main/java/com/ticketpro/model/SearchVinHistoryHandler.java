package com.ticketpro.model;

public interface SearchVinHistoryHandler {
    public void searchVinHistory(Ticket ticket);
}
