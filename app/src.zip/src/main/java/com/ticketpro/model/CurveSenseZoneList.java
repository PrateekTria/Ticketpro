package com.ticketpro.model;

public class CurveSenseZoneList {


    /**
     * Id : 5864
     * Name : Assay St
     */

    private int Id;
    private String Name;

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }
}
