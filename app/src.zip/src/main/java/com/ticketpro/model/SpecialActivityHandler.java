package com.ticketpro.model;

import java.util.ArrayList;

public interface SpecialActivityHandler {
    public void specialActivityHandler(ArrayList<SpecialActivityReport> list);
}
