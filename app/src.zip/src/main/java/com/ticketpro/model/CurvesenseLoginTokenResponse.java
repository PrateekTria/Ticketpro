package com.ticketpro.model;

public class CurvesenseLoginTokenResponse {


    /**
     * Token : eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IlR1cmJvRGF0YSIsIm5hbWVpZCI6IjgwNzYiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9sb2NhbGl0eSI6IjI3IiwiYWN0b3J0IjoiQ3VyYlNlbnNlRXZlbnRFeHBvcnQiLCJuYmYiOjE3MjkxNTA0MDUsImV4cCI6MTcyOTE1NzYwNSwiaWF0IjoxNzI5MTUwNDA1LCJpc3MiOiJQRU1TIiwiYXVkIjoiRXh0ZXJuYWxNZXRlclRyYW5zIn0.oxzTQuANVQ2naG2aAqcRHgyYstRZA9hzbJcfbduI-V0
     */

    private String Token;

    public String getToken() {
        return Token;
    }

    public void setToken(String Token) {
        this.Token = Token;
    }
}
