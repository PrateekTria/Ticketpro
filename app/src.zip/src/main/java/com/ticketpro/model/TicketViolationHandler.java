package com.ticketpro.model;

import java.util.ArrayList;

public interface TicketViolationHandler {
    public void ticketViolationHandler(ArrayList<TicketViolation> ticketViolationList);
}
